./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RJYY2kionbjyEuhLWvN6t3NDgTD34YFRJg.a1 -p d=16384s,hybrid --cpu 2
